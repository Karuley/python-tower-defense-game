<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="towerDefense_vector" tilewidth="48" tileheight="48" tilecount="510" columns="30">
 <image source="kenney_tower-defense-top-down/Vector/towerDefense_vector.svg" width="1472" height="832"/>
</tileset>

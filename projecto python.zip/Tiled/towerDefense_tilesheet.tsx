<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="towerDefense_tilesheet" tilewidth="64" tileheight="64" tilecount="299" columns="23">
 <image source="kenney_tower-defense-top-down/Tilesheet/towerDefense_tilesheet.png" width="1472" height="832"/>
</tileset>

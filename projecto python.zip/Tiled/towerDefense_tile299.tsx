<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="towerDefense_tile299" tilewidth="48" tileheight="48" tilecount="1" columns="1">
 <image source="kenney_tower-defense-top-down/PNG/Default size/towerDefense_tile299.png" trans="ff00ff" width="64" height="64"/>
</tileset>
